<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class client-mail extends Model
{
    //
}
