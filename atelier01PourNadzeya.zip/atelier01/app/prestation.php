<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class prestation extends Model
{
    //
}
