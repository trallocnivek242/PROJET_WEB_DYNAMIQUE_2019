<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chanti-pv extends Model
{
    //
}
