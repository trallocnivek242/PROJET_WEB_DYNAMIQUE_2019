<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chanti-interv extends Model
{
    //
}
