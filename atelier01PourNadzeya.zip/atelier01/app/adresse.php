<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adresse extends Model
{
    //
}
