<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class corps_metier extends Model
{
    //
}
