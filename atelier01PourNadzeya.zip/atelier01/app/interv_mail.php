<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class interv_mail extends Model
{
    //
}
