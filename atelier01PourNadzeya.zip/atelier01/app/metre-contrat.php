<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class metre-contrat extends Model
{
    //
}
