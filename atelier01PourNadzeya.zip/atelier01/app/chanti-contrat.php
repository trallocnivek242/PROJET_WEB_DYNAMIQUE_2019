<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chanti-contrat extends Model
{
    //
}
