<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contrat-client extends Model
{
    //
}
