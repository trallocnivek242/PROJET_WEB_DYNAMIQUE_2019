<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class intervenant extends Model
{
    //
}
